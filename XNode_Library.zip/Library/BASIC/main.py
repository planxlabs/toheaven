from pop import Leds, Switches, Buzzer,Led
import time

l = Leds()
s = Switches()
b = Buzzer()
ll=Led()
ll.on()
time.sleep(1)
ll.off()
time.sleep(1)
ll.on()
'''
for i in range(3):
    b.on()
    time.sleep(0.5)
    b.off()
    time.sleep(0.5)

for i in l:
    i.on()
    time.sleep(0.3)
    i.off()
    time.sleep(0.3)
'''
l.allOn()

while True:
    print(s[0].read(), s[1].read())
    time.sleep(0.5)

l.allOff()
