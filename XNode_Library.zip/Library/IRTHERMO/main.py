from pop import Temp
import time

t = Temp()

while True:
    print("Temp : ", t.read())
    time.sleep(0.2)


