from pop import Pir
import time

p = Pir()

while True:
    print(p.read())
    time.sleep(0.1)
