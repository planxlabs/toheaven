from pop import GPS, xnode
import time

g = GPS()
flag=0

while True:
    a = str(g.read())
    b = str(g.read("coordinate"))
    c=[]
    
    for i in range(int(len(a)/100)):
        c.append(a[i*100:(i+1)*100])
    
    c.append(a[len(c)*100:])
    
    for i in c:    
        xnode.transmit(xnode.ADDR_COORDINATOR,i)
        
    xnode.transmit(xnode.ADDR_COORDINATOR,b)
    print(a)
    print(b)
    time.sleep(10)
