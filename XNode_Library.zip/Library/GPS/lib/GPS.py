from machine import I2C
import time

class SC16IS750:
    CrystalFrequency = 0

    def __init__(self, crystalFrequency=12000000, deviceAddress=0x9A):
        self._i2c = I2C(1,freq=100000)
        self.crystalFrequency = crystalFrequency
        self.DEVICE_ADDRESS = deviceAddress

        self.writeRegister(0x03, 0x80)
        self.writeRegister(0x00, 0x4E)
        self.writeRegister(0x01, 0x00)
        self.writeRegister(0x03, 0xBF)
        self.writeRegister(0x02, 0x10)
        self.writeRegister(0x03, 0x03)
        self.writeRegister(0x01, 0x00)
        self.writeRegister(0x02, 0x07)

    def readRegister(self, registerAddress):
        shiftedDeviceAddress = self.DEVICE_ADDRESS >> 1
        shiftedRegisterAddress = registerAddress << 3
        registerReadValue = self._i2c.readfrom_mem(shiftedDeviceAddress, shiftedRegisterAddress,1)
        return ord(registerReadValue)

    def writeRegister(self, registerAddress, data):
        shiftedDeviceAddress = self.DEVICE_ADDRESS >> 1
        shiftedRegisterAddress = registerAddress << 3
        self._i2c.writeto_mem(shiftedDeviceAddress, shiftedRegisterAddress, chr(data))

    ##Checks if any data in FIFO buffer##
    def isDataWaiting(self):
        register = self.readRegister(0x05)
        isWaiting = register & 0b1
        if (isWaiting):
            return True
        return False

    ##Checks number of bytes waiting in FIFO buffer##
    def dataWaiting(self):
        return self.readRegister(0x09)

    ##Writes to Scratch register and checks successful##
    def testChip(self):
        self.writeRegister(0x07, 0xFF)
        if (self.readRegister(0x07) != 0xFF):
            return False
        return True

    def read(self):
        return self.readRegister(0x00)

    def write(self,data):
        self.writeRegister(0x00, data)

class GPS:
    UPDATE_100_MILLIHERTZ = "$PMTK220,10000*2F"
    UPDATE_200_MILLIHERTZ = "$PMTK220,5000*1B"
    UPDATE_1HZ = "$PMTK220,1000*1F"
    UPDATE_2HZ = "$PMTK220,500*2B"
    UPDATE_5HZ = "$PMTK220,200*2C"
    UPDATE_10HZ = "$PMTK220,100*2F"
    OUTPUT_RMC = "$PMTK314,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*29"
    OUTPUT_VTG = "$PMTK314,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*29"
    OUTPUT_GGA = "$PMTK314,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*29"
    OUTPUT_GSA = "$PMTK314,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0*29"
    OUTPUT_GSV = "$PMTK314,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0*29"
    OUTPUT_OFF = "$PMTK314,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*28"

    def __init__(self):
        self._uart = SC16IS750()
        self.send_message(self.OUTPUT_GGA)

    def read(self, *args):
        current_time = time.ticks_ms()
        data = ''
        _data = 0

        data_flag = True

        while (data_flag is not False) and (time.ticks_ms()-current_time<5000):
            l = self._uart.dataWaiting()

            for i in range(l):
                _data = self._uart.read()
                if _data is not 10:
                    data += chr(_data)
                else:
                    data_flag=False
                    
        _p_data = self.parsing(data)

        if len(args) > 0:
            
            '''
            _p_data = self.parsing(data)
            p_data = {}

            for arg in args:
                p_data[arg.lower()] = _p_data[arg.lower()]

            return p_data
            '''

            if args[0].lower()=='coordinate':
                
                try:
                    return (_p_data['latitude'], _p_data['ns_indicator'], _p_data['longitude'], _p_data['ew_indicator'])
                except:
                    return None
                #if int(_p_data['Satellites_Used']) >= 0:
                #    return dict(Latitude=_p_data['Latitude'],NS_Indicator=_p_data['NS_Indicator'],Longitude=_p_data['Longitude'],EW_Indicator = _p_data['EW_Indicator'])
        return _p_data

    def parsing(self, _data):
        d = ['']
        j = 0
        if len(_data) < 5:
            return None

        for i in range(len(_data)):
            if _data[i] is not ',':
                d[j] += _data[i]
            else:
                d.append('')
                j = j + 1

        if j<2:
            return None
        else :
            data = None

            if d[0] is "$GPGGA":
                try:
                    data = dict(id=d[0], utctime=d[1], latitude=d[2], ns_indicator=d[3], longitude=d[4], ew_indicator=d[5],
                                position_fix_indicator=d[6], satellites_used =d[7], hdop = d[8], msl_altitude = d[9],
                                units_a = d[10], geoidal_separation = d[11], units_g = d[12], age_diff_corr = d[13], checksum = d[14])
                except:
                    print("error $GPGGA")
            elif d[0] is "$GPGSA":
                try:
                    data = dict(ID=d[0], Mode1=d[1], Mode2=d[2], Satellites_Used_CH1=d[3], Satellites_Used_CH2=d[4], Satellites_Used_CH3=d[5],
                                Satellites_Used_CH4=d[6], Satellites_Used_CH5 =d[7], Satellites_Used_CH6 = d[8], Satellites_Used_CH7 = d[9],
                                Satellites_Used_CH8 = d[10], Satellites_Used_CH9 = d[11], Satellites_Used_CH10 = d[12], Satellites_Used_CH11 = d[13],
                                Satellites_Used_CH12 = d[14], PDOP = d[15], HDOP = d[16], VDOP = d[17][0], Checksum = d[17][1:])
                except:
                    print("error $GPGSA")

            elif d[0] is "$GPGSV":
                try:
                    data = dict(ID=d[0], Num_Messages=d[1], Message_Num1=d[2], Satellites_in_View=d[3],
                                Satellite_ID_1=d[4], Elevation_1=d[5],Azimuth_1=d[6], SNR_1 =d[7],
                                Satellite_ID_2 = d[8], Elevation_2 = d[9], Azimuth_2 = d[10], SNR_2 = d[11],
                                Satellite_ID_3 = d[12], Elevation_3 = d[13], Azimuth_3 = d[14], SNR_3 = d[15],
                                Satellite_ID_4 = d[16], Elevation_4 = d[17], Azimuth_4 = d[18], SNR_4 = d[19][0], Checksum = d[19][1:])
                except:
                    print("error $GPGSV")

            elif d[0] is "$GPRMC":
                try:
                    data = dict(ID=d[0], UTCTime=d[1], Status=d[2], Latitude=d[3], NS_Indicator=d[4], Longitude=d[5], EW_Indicator=d[6],
                                Speed_over_Ground=d[7], Course_over_Ground =d[8], Date = d[9], Magnetic_Variation = d[10],
                                Mode = d[11][0], Checksum = d[11][1:])
                except:
                    print("error $GPRMC")

            elif d[0] is "$GPVTG":
                try:
                    data = dict(ID=d[0], Course_A=d[1], Reference_A=d[2], Course_B=d[3], Reference_B=d[4], Speed_KN=d[5],
                                Units_KN=d[6], Speed_KM =d[7], Units_KM = d[8], Mode = d[9][0], Checksum = d[9][1:])
                except:
                    print("error $GPVTG")
            else:
                return None

            return data

    def send_message(self, message):
        for i in range(len(message)):
            self._uart.write(ord(message[i]))
        self._uart.write(0xD)
        self._uart.write(0xA)
        time.sleep(1)